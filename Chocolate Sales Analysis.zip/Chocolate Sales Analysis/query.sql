create table sale_data 
(
salesperson text,
product text,
Date date,
sales int ,
boxes int,
expenses int ,
category text
);

copy sale_data from 'C:\Program Files\PostgreSQL\17\data\Chocolate_sales\Chocolate_sales_data.csv' Delimiter ',' csv header;

select * from sale_data limit 5;

--Count no. of sale which are  Loss, Break-even, or Profit

select count(*),
case 
when sales-expenses <0 then 'Loss'
when sales-expenses =0 then 'Break-even'
else 'Profit'
end as Profit_Status from sale_data group by Profit_Status;

--Flag Inefficient Sales (Expense > 60% of Sales)
select count(*),
case 
when sales*.6 < expenses 	 then 'Inefficient'
else 'Efficient'
end as efficiency_flag from sale_data group by efficiency_flag;

--Products where average expense per box is unusually high (e.g., > $8/box)
SELECT 
  Product,
  SUM(Boxes) AS Total_Boxes,
  SUM(Expenses) AS Total_Expenses,
  ROUND(SUM(Expenses) / NULLIF(SUM(Boxes), 0), 2) AS Expense_Per_Box
FROM sale_data
GROUP BY Product
HAVING ROUND(SUM(Expenses) / NULLIF(SUM(Boxes), 0), 2) > 8
ORDER BY 4 DESC;

--Salespersons Whose profit per box is low

select salesperson,sum(boxes) as Total_Boxes ,sum(sales-expenses) as Total_Profit from sale_data 
group by salesperson HAVING sum(sales-expenses)/sum(boxes)  < 10;

--Products Contributing lesser than Average Profit 
select Product,total_profit,round(avg_per_prod,1) as avg_per_prod from(
select *,avg(total_profit) over() as avg_per_prod 
from (
select distinct Product,sum(sales-expenses)over(partition by Product) as total_profit from sale_data)a )b where total_profit < avg_per_prod
;

--Category Contributing lesser than Average Profit 
select category,total_profit,round(avg_per_cat,1)as avg_per_cat from(
select *,avg(total_profit) over() as avg_per_cat 
from (
select distinct category,sum(sales-expenses)over(partition by category) as total_profit from sale_data)a )b where total_profit < avg_per_cat
;
----Salesperson Contributing lesser than Average Profit 
select salesperson,total_profit,round(avg_per_sp,1)as avg_per_sp from(
select *,avg(total_profit) over() as avg_per_sp 
from (
select distinct salesperson,sum(sales-expenses)over(partition by salesperson) as total_profit from sale_data)a )b where total_profit < avg_per_sp
;

----Loss making Products for Salespersons  
select salesperson,product,sum(sales-expenses) as Total_Profit from sale_data 
group by salesperson,product  HAVING sum(sales-expenses)  < 0;

----Loss making categories for Salespersons  
select salesperson,category,sum(sales-expenses) as Total_Profit from sale_data 
group by salesperson,category  HAVING sum(sales-expenses)  < 0;




SELECT distinct DATE_TRUNC('month', date) AS month from sale_data;

select distinct product from sale_data;


















